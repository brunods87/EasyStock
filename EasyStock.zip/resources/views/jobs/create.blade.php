@extends('layouts.app')


@section('content')

<div class="container py-3">
	{!! $form !!}
</div>


@endsection