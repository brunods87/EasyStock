@extends('layouts.app')

@section('content')
<div class="home-background w-100 h-100" style="background-image: url('/images/wallpaper.jpg');background-repeat: no-repeat;background-position: center;background-size: cover;">
    
</div>
@endsection
