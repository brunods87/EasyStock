


<?php $__env->startSection('content'); ?>

<div class="container py-5">
	<h1 class="text-center">Editar Categoria</h1>
	<div class="toolbar text-right">
        <a href="<?php echo e(route('categories.index')); ?>">Voltar</a>    
    </div>
	<?php echo $form; ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bruno\Documents\Programacao\Applications\EasyStock\resources\views/categories/update.blade.php ENDPATH**/ ?>