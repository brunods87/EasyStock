


<?php $__env->startSection('content'); ?>

<div class="container py-3">
	<?php echo $form; ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bruno\Documents\Programacao\Applications\EasyStock\resources\views/jobs/create.blade.php ENDPATH**/ ?>