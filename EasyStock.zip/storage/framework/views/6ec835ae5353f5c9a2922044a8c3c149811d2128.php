

<?php $__env->startSection('content'); ?>

<div class="container py-3">

    <h1 class="title">MATERIAIS</h1>
    <div class="toolbar text-right">
        <a href="<?php echo e(route('unities.index')); ?>"><i class="fas fa-list mr-3"></i>Unidades</a>
        <a href="<?php echo e(route('types.index')); ?>"><i class="fas fa-list mr-3"></i>Tipos</a>
        <a href="<?php echo e(route('categories.index')); ?>"><i class="fas fa-list mr-3"></i>Categorias</a>    
        <a href="<?php echo e(route('materials.create')); ?>"><i class="far fa-plus-square mr-3"></i>Adicionar</a>    
    </div>
    

    <table class="table table-bordered data-table">

        <thead>

            <tr>

                <th>Nº</th>
                <th>Referência</th>
                <th>Nome</th>
                <th>Preço</th>
                <th>Unidade</th>
                <th>Fornecedor</th>
                <th>Categoria</th>
                <th>Tipo</th>
                <th>Stock</th>
                <th width="100px">Ações</th>

            </tr>

        </thead>

        <tbody>

        </tbody>

    </table>

</div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">
  $(function () {
    
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('materials.index')); ?>",
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'reference', name: 'reference'},
            {data: 'name', name: 'name'},
            {data: 'price', name: 'price'},
            {data: 'unity_id', name: 'unity'},
            {data: 'supplier_id', name: 'supplier_id'},
            {data: 'category_id', name: 'category_id'},
            {data: 'type_id', name: 'type_id'},
            {data: 'stock', name: 'stock'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ],
        "order": [[ 1, "asc" ]]
    });
    
  });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bruno\Documents\Programacao\Applications\EasyStock\resources\views/materials/index.blade.php ENDPATH**/ ?>