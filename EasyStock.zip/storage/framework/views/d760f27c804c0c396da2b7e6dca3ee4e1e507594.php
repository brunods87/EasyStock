

<?php $__env->startSection('content'); ?>

<div class="container py-3">

    <h1 class="title">FATURAS</h1>
    <div class="toolbar text-right">
        <a href="<?php echo e(route('invoices.create')); ?>"><i class="far fa-plus-square mr-3"></i>Adicionar</a>
    </div>
    <table class="table table-bordered data-table">

        <thead>

            <tr>

                <th>No</th>
                <th>Número</th>
                <th>Fornecedor</th>
                <th>Data</th>
                <th>Materiais</th>
                <th>Total</th>
                <th width="170px">Ações</th>

            </tr>

        </thead>

        <tbody>

        </tbody>

    </table>

</div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">
  $(function () {
    
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('invoices.index')); ?>",
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'number', name: 'number'},
            {data: 'supplier_id', name: 'supplier_id'},
            {data: 'date', name: 'date'},
            {data: 'materials', name: 'materials'},
            {data: 'total', name: 'total'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bruno\Documents\Programacao\Applications\EasyStock\resources\views/invoices/index.blade.php ENDPATH**/ ?>