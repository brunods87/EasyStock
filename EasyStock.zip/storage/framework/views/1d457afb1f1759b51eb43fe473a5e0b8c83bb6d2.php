<?php $__env->startSection('content'); ?>
<div class="home-background w-100 h-100" style="background-image: url('/images/wallpaper.jpg');background-repeat: no-repeat;background-position: center;background-size: cover;">
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bruno\Documents\Programacao\Applications\EasyStock\resources\views/home.blade.php ENDPATH**/ ?>