<?php

use App\Job;

?>




<?php $__env->startSection('content'); ?>
<div class="row mx-0">
<aside class="col-2 sidebar">
	<div class="sidebar-inner">
		<h2 class="text-center">Fatura</h2>
		<div class="data">
			
			<table class="table table-bordered view-table">
				<tr>
					<th>Número</th>
					<td><?php echo e($invoice->number); ?></td>
				</tr>
				<tr>
					<th>Fornecedor</th>
					<td><?php echo e($invoice->supplier->name); ?></td>
				</tr>
				<tr>
					<th>Data</th>
					<td><?php echo e($invoice->date); ?></td>
				</tr>
				<tr>
					<th>Total Ilíquido</th>
					<td><?php echo e(number_format($invoice->subtotal(),2,',','.')); ?> €</td>
				</tr>
				<tr>
					<th>Total Descontos</th>
					<td><?php echo e(number_format($invoice->totalDiscount(),2,',','.')); ?> €</td>
				</tr>
				<tr>
					<th>Total Líquido</th>
					<td><?php echo e(number_format($invoice->subtotal(true),2,',','.')); ?> €</td>
				</tr>
				<tr>
					<th>Total IVA</th>
					<td><?php echo e(number_format($invoice->totalTax(),2,',','.')); ?> €</td>
				</tr>
				<tr>
					<th>Total a pagar</th>
					<td><?php echo e(number_format($invoice->getTotal(),2,',','.')); ?> €</td>
				</tr>
			</table>
			
		</div>
	</div>
</aside>
<div class="col-10">
	<div class="container-fluid py-3">
		<h1 class="mb-3 text-center">Elementos da Fatura</h1>
		<div class="toolbar text-right">
	        <a href="<?php echo e(route('invoices.index')); ?>">Voltar</a>    
	    </div>
		<div class="row justify-content-center mt-5">
			
			<div class="form col-12">
				<form method="POST" action="<?php echo e(route('invoiceItem.store')); ?>">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="invoiceID" value="<?php echo e($invoice->id); ?>">
				<div class="col-12">
					
					<table class="table table-bordered text-center" id="invoiceItems">
						
						<thead>
							<tr>
								<th>Referência</th>
								<th>Descrição</th>
								<th>Unidade</th>
								<th style="width: 70px;">Qtd</th>
								<th>Preço Unitário</th>
								<th style="width: 180px;">Desconto</th>
								<th>IVA</th>
								<th>Total</th>
								<th>Obra</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $invoice->invoice_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td class="reference"><?php echo e($item->material->reference); ?><input type="hidden" name="material_id[]" value="<?php echo e($item->material->id); ?>"></td>
								<td class="name"><?php echo e($item->material->name); ?><input type="hidden" name="item_id[]" value="<?php echo e($item->id); ?>"></td>
								<td class="unity"><?php echo e($item->material->unity->name); ?></td>
								<td class="quantity">
									<input type="number" class="quantity-input" data-id="<?php echo e($item->material->id); ?>" onclick="select();" name="quantity[]" value="<?php echo e(floatval($item->quantity)); ?>" step="0.01" min="0">
								</td>
								<td class="price"><?php echo e($item->material->price); ?></td>
								<td class="discount"><input type="number" class="material-discount" min=0 onclick="select();" name="discount_1[]" value="<?php echo e(floatval($item->discount_1)); ?>"> + <input type="number" name="discount_2[]" class="extra-discount" min=0 onclick="select();" value="<?php echo e(floatval($item->discount_2)); ?>"></td>
								<td class="tax"><?php echo e($item->material->tax); ?></td>
								<td class="total"><?php echo e($item->total()); ?> €</td>
								<td class="job"><select class="job-select" name="job[]"><?php echo Job::dropdownSelect($item->job_id); ?></select></td>
								<td><button type="button" data-id="<?php echo e($item->id); ?>" class="btn btn-danger delete-row"><i class="fas fa-trash"></i></button></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>

					</table>
					<div class="text-center">
						<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createMaterialModal"><i class="far fa-plus-square"></i></button>
						<input type="submit" class="btn btn-primary" name="" value="Guardar">
					</div>
					<?php echo $__env->make('modals.createMaterialModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				</div>
				</form>
			</div>
		</div>
	</div>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

	<script type="text/javascript">
		$(function () {
    
		    var table = $('.data-table-modal').DataTable({
		        processing: true,
		        serverSide: true,
		        ajax: "<?php echo e(route('materials.insert')); ?>",
		        columns: [
		            {data: 'id', name: 'id', className: 'id'},
		            {data: 'name', name: 'name', className: 'name'},
		            {data: 'reference', name: 'reference', className: 'reference'},
		            {data: 'price', name: 'price', className: 'price'},
		            {data: 'unity_id', name: 'unity', className: 'unity'},
		            {data: 'supplier_id', name: 'supplier_id', className: 'supplier'},
		            {data: 'category_id', name: 'category_id', className: 'category'},
		            {data: 'type_id', name: 'type_id', className: 'type'},
		            {data: 'stock', name: 'stock', className: 'stock'},
		            {data: 'discount', name: 'discount', className: 'discount'},
		            {data: 'tax', name: 'tax', className: 'tax'},
		            {data: 'action', name: 'action', orderable: false, searchable: false},
		        ],
		        "order": [[ 1, "asc" ]]
		    });
		    
		  });
	</script>
	<script type="text/javascript">
		var jobsArray = [];
		var jobsDropdown = '<option value=""></option>';
		function insertMaterial(el)
		{
			var row = el.closest('tr');
			var material = {
				id: Number(row.querySelector('.id').textContent),
				reference: row.querySelector('.reference').textContent,
				name: row.querySelector('.name').textContent,
				unity: row.querySelector('.unity').textContent,
				price: row.querySelector('.price').textContent,
				discount: row.querySelector('.discount').textContent,
				tax: row.querySelector('.tax').textContent
			}

			var html = '<tr><td class="reference">'+material.reference+'<input type="hidden" name="material_id[]" value="'+material.id+'"></td><td class="name">'+material.name+'<input type="hidden" name="item_id[]" value="0"></td><td class="unity">'+material.unity+'</td><td class="quantity"><input type="number" class="quantity-input" onclick="select();" data-id="'+material.id+'" name="quantity[]" value="0" step="0.01" min="0"></td><td class="price">'+material.price+'</td><td class="discount"><input type="number" name="discount_1[]" class="material-discount" value='+material.discount+' onclick="select();" data-id="'+material.id+'" min="0"> + <input type="number" value=0 onclick="select();" name="discount_2[]" class="extra-discount" data-id="'+material.id+'" min="0"></td><td class="tax">'+material.tax+'</td><td class="total">0,00 €</td><td><select class="job-select" name="job[]">'+jobsDropdown+'</select></td><td><button type="button" class="btn btn-danger delete-row"><i class="fas fa-trash"></i></button></td></tr>';
			$('#invoiceItems tbody').append(html);
			
		}

		$(document).ready(function(){

			
			$.ajax({
				type: 'POST',
				url: '<?php echo e(route('jobs.getJobs')); ?>',
			}).done(function(response){
				jobsArray = response;
				jobsArray.forEach(function(el){
					jobsDropdown += '<option value="'+el.id+'">REF: '+el.reference+' | NOME: '+el.name+'</option>';
				});
			});

			$(document).on('change', '#invoiceItems td input', function(event){

				var id = event.target.dataset.id;
				var row = event.target.closest('tr');
				var price = Number(row.querySelector('.price').textContent);
				var quantity = Number(row.querySelector('.quantity-input').value);
				var discount_1 = Number(row.querySelector('.material-discount').value);
				var discount_2 = Number(row.querySelector('.extra-discount').value);
				
				if (discount_1 > 0){
					var sub = price * (discount_1/100);
					price -= sub; 
				}
				if (discount_2 > 0){
					var sub2 = price * (discount_2/100);
					price -= sub2; 
				}
				var total = price * quantity;
				row.querySelector('.total').innerHTML = total.toFixed(2) + " €";
				
			});
			$(document).on('click', '#invoiceItems td .delete-row', function(event){
				var id = $(this).data('id');
				if (id){
					if (confirm('Eliminar o elemento da fatura?')){
						$.ajax({
							type: 'POST',
							url: '<?php echo e(route("invoiceItem.destroy")); ?>',
							data: {id: id}
						}).done(function(response){
							alert(response.msg);
							location.reload();
						});
					}
				}else{
					$(this).parent().parent().remove();
				}
			});

		});
	</script>
	
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bruno\Documents\Programacao\Applications\EasyStock\resources\views/invoices/view.blade.php ENDPATH**/ ?>